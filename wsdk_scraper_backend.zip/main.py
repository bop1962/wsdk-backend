
from fastapi import FastAPI, Query
from fastapi.middleware.cors import CORSMiddleware
import requests
from bs4 import BeautifulSoup

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
def root():
    return {"message": "Scraper backend actief"}

@app.get("/api/woningen")
def get_woningen(locatie: str = Query(...)):
    # Simulatie van scraping Jaap.nl
    dummy_resultaten = [
        {
            "adres": "Burgemeester Verwielstraat 12, Oisterwijk",
            "prijs": "€639.000",
            "type": "Tussenwoning",
            "oppervlakte": "138 m²",
            "bouwjaar": 2008,
            "link": "https://www.jaap.nl/aanbod/koop/oisterwijk/burgemeester+verwielstraat+12",
            "foto": "https://img.jaap.nl/oisterwijk/burgemeester-verwielstraat-12/voorgevel.jpg"
        },
        {
            "adres": "Kerkstraat 8, Oisterwijk",
            "prijs": "€729.000",
            "type": "Vrijstaande woning",
            "oppervlakte": "172 m²",
            "bouwjaar": 2001,
            "link": "https://www.jaap.nl/aanbod/koop/oisterwijk/kerkstraat+8",
            "foto": "https://img.jaap.nl/oisterwijk/kerkstraat-8/voorgevel.jpg"
        }
    ]
    return dummy_resultaten
